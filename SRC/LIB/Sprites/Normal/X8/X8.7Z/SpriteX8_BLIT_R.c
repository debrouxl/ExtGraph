extern void __attribute__((__stkparm__)) SpriteX8_BLIT(short x,short y,short h,unsigned char* sprite,unsigned char* maskval,short bytewidth,void* dest);

void __attribute__((__stkparm__)) SpriteX8_BLIT_R(register short x asm("%d0"),register short y asm("%d1"),register short h asm("%d2"),register unsigned char *sprt asm("%a1"),unsigned char *maskval,register short w asm("%d3"),register void *dest asm("%a0")) {
    SpriteX8_BLIT(x,y,h,sprt,maskval,w,dest);
/*
    register unsigned char* addr  = ((unsigned char*)dest)+((y<<5)-(y<<1)+(x>>3));
    register unsigned char* mask;
    register unsigned short shift1 = x & 7;
    register unsigned short shift2;
    register unsigned short lineoffset = 30-w;
    register          short loop;
    register unsigned char  startmask;
    register unsigned char  endmask;

    if (shift1) {
        shift2 = 8 - shift1;
        startmask = 0xff << shift2;
        endmask   = 0xff >> shift1;
        for (;h;h--,addr+=lineoffset) {
            mask = maskval;
            *addr   &= ((*mask) >> shift1) | startmask;
            *addr++ |= *sprt >> shift1;
            for (loop=1;loop<w;loop++) {
               unsigned char val = (*mask++) << shift2;
               *addr   &= val | ((*mask) >> shift1);
               *addr   |= ((*sprt++) << shift2);
               *addr++ |= (*sprt >> shift1);
            }
            *addr &= ((*mask++) << shift2) | endmask;
            *addr |= (*sprt++ << shift2);
        }
    }
    else {
        for (;h;h--,addr+=lineoffset) {
            mask = maskval;
            for (loop=0;loop<w;loop++) {
                *addr   &= *mask++;
                *addr++ |= *sprt++;
            }
        }
    }
*/
}

