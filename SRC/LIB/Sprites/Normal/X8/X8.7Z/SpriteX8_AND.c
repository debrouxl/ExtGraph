void __attribute__((__stkparm__)) SpriteX8_AND(short x,short y,short h,unsigned char* sprite,short bytewidth,void* dest) {
    register unsigned char* addr  = ((unsigned char*)dest)+((y<<5)-(y<<1)+(x>>3));
    register unsigned short mask1 = x & 7;
    register unsigned short mask2;
    register unsigned short lineoffset = 30-bytewidth;
    register          short loop;
    register unsigned char  startmask;
    register unsigned char  endmask;

    if (mask1) {
        mask2 = 8 - mask1;
        startmask = 0xff << mask2;
        endmask   = 0xff >> mask1;
        for (;h;h--,addr+=lineoffset) {
            *addr++ &= (*sprite >> mask1) | startmask;
            for (loop=1;loop<bytewidth;loop++) {
               unsigned char val = ((*sprite++) << mask2);
               *addr++ &= val | (*sprite >> mask1);
            }
            *addr &= (*sprite++ << mask2) | endmask;
        }
    }
    else {
        for (;h;h--,addr+=lineoffset) {
            for (loop=0;loop<bytewidth;loop++) *addr++ &= *sprite++;
        }
    }
}

