extern void __attribute__((__stkparm__)) SpriteX8Get(short x,short y,short h,void* src,unsigned char* dest,short bytewidth);

void __attribute__((__regparm__)) SpriteX8Get_R(register short x asm("%d0"),register short y asm("%d1"),register short h asm("%d2"),register void *src asm("%a1"),register unsigned char *dest asm("%a0"),register short bytewidth asm("%d3")) {
    SpriteX8Get(x,y,h,src,dest,bytewidth);
/*
    register unsigned char* addr  = ((unsigned char*)src)+((y<<5)-(y<<1)+(x>>3));
    register unsigned short mask1 = x & 7;
    register unsigned short mask2;
    register unsigned short lineoffset = 30-bytewidth;
    register          short loop;

    if (mask1) {
        mask2 = 8 - mask1;
        for (;h;h--,addr+=lineoffset) {
            *dest = (*addr++) << mask1;
            for (loop=1;loop<bytewidth;loop++) {
               *dest++ |= (*addr >> mask2);
               *dest = (*addr++) << mask1;
            }
            *dest++ |= (*addr >> mask2);
        }
    }
    else {
        for (;h;h--,addr+=lineoffset) {
            for (loop=0;loop<bytewidth;loop++) *dest++ = *addr++;
        }
    }
*/
}
