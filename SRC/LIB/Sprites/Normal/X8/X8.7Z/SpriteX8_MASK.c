void __attribute__((__stkparm__)) SpriteX8_MASK(short x,short y,short h,unsigned char* sprite,unsigned char* mask,short bytewidth,void* dest) {
    register unsigned char* addr  = ((unsigned char*)dest)+((y<<5)-(y<<1)+(x>>3));
    register unsigned short shift1 = x & 7;
    register unsigned short shift2;
    register unsigned short lineoffset = 30-bytewidth;
    register          short loop;
    register unsigned char  startmask;
    register unsigned char  endmask;

    if (shift1) {
        shift2 = 8 - shift1;
        startmask = 0xff << shift2;
        endmask   = 0xff >> shift1;
        for (;h;h--,addr+=lineoffset) {
            *addr   &= ((*mask) >> shift1) | startmask;
            *addr++ |= *sprite >> shift1;
            for (loop=1;loop<bytewidth;loop++) {
               unsigned char val = (*mask++) << shift2;
               *addr   &= val | ((*mask) >> shift1);
               *addr   |= ((*sprite++) << shift2);
               *addr++ |= (*sprite >> shift1);
            }
            *addr &= ((*mask++) << shift2) | endmask;
            *addr |= (*sprite++ << shift2);
        }
    }
    else {
        for (;h;h--,addr+=lineoffset) {
            for (loop=0;loop<bytewidth;loop++) {
                *addr   &= *mask++;
                *addr++ |= *sprite++;
            }
        }
    }
}
