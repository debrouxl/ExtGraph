void __attribute__((__regparm__)) SpriteX8_OR_R(register short x asm("%d0"), register short y asm("%d1"),register short h asm("%d2"),register unsigned char *sprt asm("%a1"),register short w asm("%d3"),register void *dest asm("%a0")) {
    register unsigned char* addr  = ((unsigned char*)dest)+((y<<5)-(y<<1)+(x>>3));
    register unsigned short mask1 = x & 7;
    register unsigned short mask2;
    register unsigned short lineoffset = 30-w;
    register          short loop;

    if (mask1) {
        mask2 = 8 - mask1;
        for (;h;h--,addr+=lineoffset) {
            *addr++ |= *sprt >> mask1;
            for (loop=1;loop<w;loop++) {
               *addr |= ((*sprt++) << mask2);
               *addr++ |= (*sprt >> mask1);
            }
            *addr |= (*sprt++ << mask2);
        }
    }
    else {
        for (;h;h--,addr+=lineoffset) {
            for (loop=0;loop<w;loop++) *addr++ |= *sprt++;
        }
    }
}
