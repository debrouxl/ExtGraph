| SpriteX82.h - Macros pour les fonctions SpriteX8 am�lior�es (?)

| Calcul l'offset � ajouter � l'adresse du plan de destination, et l'ajoute
| � la destination
  .macro gestion_offset tmp

  add.w   %d1,%d1
  move.w  %d1,\tmp
  lsl.w   #4,%d1
  sub.w   \tmp,%d1
  move.w  %d0,\tmp
  lsr.w   #3,\tmp
  add.w   \tmp,%d1
  adda.w  %d1,%a1

  .endm


| Affiche le sprite d'adresse a0, vers la destination a1, en le shiftant de
| d0 pixels
  .macro affichage_sprite MODE

  subq.w  #2,%d2
  subq.w  #1,%d3
  swap.w  %d2
  move.w  %d3,%d2

  andi.w  #7,%d0
  moveq.l #-1,%d1
  lsr.b   %d0,%d1
  move.b  %d1,%d3
  not.b   %d3

Loop_Ligne_\MODE:
  swap.w  %d2

  move.b  (%a0)+,%d4
  ror.b   %d0,%d4
  move.b  %d4,%d5
  and.b   %d1,%d4
  \MODE.b %d4,(%a1)+

  move.w  %d2,%d7
  bmi.s   UneColonneSeulement_\MODE
Loop_Colonne_\MODE:
  and.b   %d3,%d5
  move.b  (%a0)+,%d4
  ror.b   %d0,%d4
  move.b  %d4,%d6
  and.b   %d1,%d4
  or.b    %d5,%d4
  \MODE.b %d4,(%a1)+
  move.b  %d6,%d5

  dbf     %d7,Loop_Colonne_\MODE

UneColonneSeulement_\MODE:
  and.b   %d3,%d5
  \MODE.b %d5,(%a1)

  moveq.l #30-2,%d4
  sub.w   %d2,%d4
  adda.w  %d4,%a1

  swap.w  %d2
  dbf     %d2,Loop_Ligne_\MODE

  .endm
